var mainHeading = document.getElementById('mainHeading');

var tl1 = new TimelineMax();
tl1.to(mainHeading, 2, {fontSize: 100});
//tl1.from(mainHeading, 2, {fontSize: 100});


